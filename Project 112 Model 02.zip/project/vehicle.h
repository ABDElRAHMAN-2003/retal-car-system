#include <iostream>
#include <string.h>
using namespace std; 

class vehicle{
    private:                                                  // all private variables :)
        int car_number;
        float car_price;
        char car_model[10];
        char car_type[10];
        char return_time[10];
        char rentled_name[20];
        bool rented;

    public:
        vehicle(int car_num,float car_p,char car_m[10],char car_ty[10],char ren_time[10],char ren_name[20],bool ren){                       //*Constructor For Class Vehicle*
            car_num=0;
            car_p=0.0;
            car_m=NULL;
            car_ty=NULL;
            ren_time=NULL;
            ren_name=NULL;
            ren = true;
        }

        void Add_Car_details(int car_num,float car_p,char car_m[10],char car_ty[10],char ret_time[10],char ren_name[20],bool ren){         //*Setter Function*
            cout<<"Enter the vehicle number: ";
            cin>> car_num;
            cout<<"Enter the vehicle price: ";
            cin >>car_p;
            cout << "Enter vehicle model: ";
            cin >> car_m;
            cout << "Enter vehicle type: ";
            cin >> car_ty;
            cout<<"if rented type 1 if not type 0: ";
            cin>> ren;

            if (ren == 1){
                cout<<"Enter return time please: ";
                cin>> ret_time;
                cout<<"Enter rentled name: ";
                cin>> ren_name;
            }

            car_number=car_num;
            car_price=car_p;
            strcpy(car_model,car_m);
            strcpy(car_type,car_ty);
            strcpy(return_time,ret_time);
            strcpy(rentled_name,ren_name);
            rented=ren;
        }


        void Get_cars_Info(){                                                                                                             //*Getter Function*
            cout<< "\n\t\t                       vehicle Rental - Data Base                  \n"
                << "\t\t	///////////////////////////////////////////////////////////\n"
                << "\t\t	| vehicle No.   :"<<"----------------------|"<<setw(10)<<car_number<<" |\n"
                << "\t\t	| vehicle Price :"<<"----------------------|"<<setw(10)<<car_price<<" |\n"
                << "\t\t	| vehicle Model :"<<"----------------------|"<<setw(10)<<car_model<<" |\n"
                << "\t\t	| vehicle Type  :"<<"----------------------|"<<setw(10)<<car_type<<" |\n";
            Rent_car(rented);

        }


        void Rent_car(bool h){
            if((h)==1){
                cout<< "\t\t	| Rentled Name  :"<<"----------------------|"<<setw(10)<<rentled_name<<" |\n"
                    << "\t\t	| Return time   :"<<"----------------------|"<<setw(10)<<return_time<<" |"<<endl;

            }
            else{
                cout<< "\t\t	|                  Not Rented                      |"<<endl;
            }
        }

};
class cbus : public vehicle{ 
    private:
        char driver_name[20];
        int num_passenger;
        
    public:
        cbus(char driv_name[20],int no_pass,int car_num,float car_p,char car_m[10],char car_ty[10],char ren_time[10],char ren_name[20],bool ren)
        :vehicle(car_num,car_p,car_m,car_ty,ren_time,ren_name,ren)
        {
          driv_name=NULL;
          no_pass=0;
        }
        
        void set_cbus(char driv_name[20],int no_pass,int car_num,float car_p,char car_m[10],char car_ty[10],char ret_time[10],char ren_name[20],bool ren){
            
            cout << "Enter Driver: ";
            cin >> driv_name;
            cout << "How many passengers?: ";
            cin >> no_pass;

            Add_Car_details(car_num,car_p,car_m,car_ty,ret_time,ren_name,ren);

            strcpy(driver_name,driv_name);
            num_passenger = no_pass;
        }

        void GetInfo(){
            Get_cars_Info();

            cout<< "\t\t	| Driver name   :"<<"----------------------|"<<setw(10)<<driver_name<<" |\n"
                << "\t\t	| Number of passengers:"<<"----------------|"<<setw(10)<<num_passenger<<" |"<<endl;
        }
};