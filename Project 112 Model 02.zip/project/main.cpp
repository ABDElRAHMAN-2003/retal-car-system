#include <bits/stdc++.h>
#include "customer.h"
#include "vehicle.h"
using namespace std;

typedef int CI;                     // Customer  integers
typedef char CC;                    // Customer  characters

typedef int VI;                     // Vehicle  integers
typedef float VF;                   // Vehicle  float
typedef char VC;                    // Vehicle  character

typedef char BI;                    // Bus  integers
typedef char BC;                    // Bus  character

int main(){
    //Eyad Yehia Mohammed
    //Elena Magdy Kamel
    //Abdelrahman Magdy Khallaf
    //Mark Hany Wadie
    //Ali Mohamed Osman


    int n_choose, i;
    char c_choose;

    CI id;                                                  //  Customer's Vars.
    CC cus_n[10],cus_em[20],em_pass[17];                    //  Customer's Vars.

    VI car_num;                                             //  Vehicle's Vars.
    VF car_p;                                               //  Vehicle's Vars.
    VC car_m[10],car_ty[10],ret_time[10],ren_name[10];      //  Vehicle's Vars.
    bool ren;                                               //  Vehicle's Vars.

    BI no_pass;
    BC driv_name[20];


    cout << "For renting a Car Enter C for Bus Enter B (Enter The Letter In Capital):  ";
    cin >> c_choose;

    cout<<"Enter the number of vehicle please: ";
    cin>>n_choose;

    customer* CData=(customer*)malloc(sizeof(customer));
    vehicle* VData= (vehicle*)malloc(sizeof(vehicle) *n_choose);
    cbus* BData= (cbus*)malloc(sizeof(cbus) *n_choose);

    switch(c_choose){
        case('C'):
            for (i=0 ;i<n_choose;i++){
                VData[i] = vehicle(car_num,car_p,car_m,car_ty,ret_time,ren_name,ren);        // constructor
                cout<<"Vehicle "<<i+1<<endl;
                VData[i].Add_Car_details(car_num,car_p,car_m,car_ty,ret_time,ren_name,ren);     // setter
            }
            CData[0].Add_customer_info(id,cus_n,cus_em,em_pass);    // customer setter
            for (i=0 ;i<n_choose;i++){
                cout<<"Vehicle"<<i+1<<endl;                     //getter
                VData[i].Get_cars_Info();
            }
            break;

        case('B'):
            for (i=0 ;i<n_choose;i++){
                BData[i]= cbus(driv_name,no_pass,car_num,car_p,car_m, car_ty, ret_time,ren_name,ren) ; // constructor
                cout<<"bus"<<i+1<<endl;
                BData[i].set_cbus(driv_name,no_pass,car_num,car_p,car_m, car_ty, ret_time,ren_name,ren);     // setter
            }
            CData[0].Add_customer_info(id,cus_n,cus_em,em_pass);    // customer setter

            for (i=0 ;i<n_choose;i++){
                cout<<"Bus"<<i+1<<endl;                     //getter
                BData[i].GetInfo();
            }
            break;
    }
    return 0;
}
