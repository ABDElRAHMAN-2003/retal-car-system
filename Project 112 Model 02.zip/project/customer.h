#include <bits/stdc++.h>
#include <string.h>
#include <conio.h>
using namespace std;

class customer{
    private:
        int Cus_ID;
        char Cus_name[10];
        char Cus_Email[20];
        char Email_Password[17];
    
    public:
        customer(int id,char cus_n[10],char cus_em[20],char em_pass[17]){              //constructor 
            id = 0;
            cus_n = NULL;
            cus_em = NULL;
            em_pass = NULL;
        }
        
        void Add_customer_info(int id,char cus_n[10],char cus_em[20],char em_pass[17]) {          //*Setter Function*
            cout<<"\n\n\n\n\n\n\n\n\t\t\t\t\t       CAR RENTAL SYSTEM \n\n";
            cout<<"\t\t\t\t\t------------------------------";
            cout<<"\n\t\t\t\t\t\t     LOGIN \n";	
            cout<<"\t\t\t\t\t------------------------------\n\n";
            cout<<"\t\t\t\t\tEnter Name: \t";
            cin >> cus_n;
            cout<<"\t\t\t\t\tEnter ID: \t";
            cin >> id;
            cout << "\t\t\t\t\tEnter E-Mail: \t";
            cin >> cus_em;
            cout << "\t\t\t\t\tEnter Password: ";
            cin >> em_pass;
            
            Cus_ID = id;
            strcpy(Cus_name,cus_n);
            strcpy(Cus_Email,cus_em);
            strcpy(Email_Password,em_pass);
        }

        void Get_Customer_info() {                                                               //*Getter Function*
            cout<< "ID: " << Cus_ID
                << " Name: " << Cus_name
                << " Emal: i" << Cus_Email
                << " Password: " << Email_Password;
        }
};